<?php

    namespace App\Models;
    use Illuminate\Database\Eloquent\Model;

    class User extends Model{
        protected $table = 'tblbooks';
        protected $fillable = [
            'bookname','yearpublish','authorid'
        ];

        public $timestamps = false;
        protected $primaryKey = 'book_id';
    }

