<?php

$router->get('/', function () use ($router) {
    return $router->app->version();
});


 $router->group(['middleware' => 'client.credentials'],function() use ($router) {
    //  SITE 1 COMMANDS
    $router->get('/books',['uses' => 'User1Controller@index']);
    $router->post('/books',['uses' => 'User1Controller@add']);
    $router->get('/books/{id}',['uses' => 'User1Controller@show']);
    $router->put('/books/{id}',['uses' => 'User1Controller@updateUser']);
    $router->delete('/books/{id}',['uses' => 'User1Controller@deleteUser']);

    $router->get('/userjob1',['uses' => 'UserJob1Controller@index']);
    $router->get('/userjob1/{id}',['uses' => 'UserJob1Controller@show']);

    // SITE 2 COMMANDS

    $router->get('/authors',['uses' => 'User2Controller@index']);
    $router->post('/authors',['uses' => 'User2Controller@add']);
    $router->get('/authors/{id}',['uses' => 'User2Controller@show']);
    $router->put('/authors/{id}',['uses' => 'User2Controller@updateUser']);
    $router->delete('/authors/{id}',['uses' => 'User2Controller@deleteUser']);
    $router->get('/authors',['uses' => 'UserJob2Controller@index']);
    $router->get('/authors/{id}',['uses' => 'UserJob2Controller@show']);


    });